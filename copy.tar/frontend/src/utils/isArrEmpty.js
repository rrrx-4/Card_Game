
export const isArrEmpty = (arr) => {

    if (arr.length === 0) {
        return true;
    }
    else {
        return false;
    }

}